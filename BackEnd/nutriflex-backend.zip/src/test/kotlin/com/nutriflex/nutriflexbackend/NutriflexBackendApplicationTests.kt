package com.nutriflex.nutriflexbackend

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class NutriflexBackendApplicationTests {

	@Test
	fun contextLoads() {
	}

}
